from math import exp, log
import math
import random
import matplotlib.pyplot as plt
import csv
from sklearn.preprocessing import StandardScaler
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score



def load_csv_data(filepath):
    """Loads CSV data and handles missing values by replacing 'NA' with the column mean."""
    with open(filepath, 'r') as file:
        csv_reader = csv.reader(file)
        header = next(csv_reader)
        data = [row for row in csv_reader]

    # Transpose data to handle columns
    columns = list(zip(*data))
    
    # Compute means, ignoring 'NA'
    means = []
    for col in columns:
        filtered = [float(x) for x in col if x != 'NA']
        mean = sum(filtered) / len(filtered) if filtered else 0
        means.append(mean)

    # Replace 'NA' with the mean of the column
    new_data = []
    for row in data:
        new_row = [float(row[i]) if row[i] != 'NA' else means[i] for i in range(len(row))]
        new_data.append(new_row)

    return new_data, header  # Return data and header for future reference


def prepare_data(data, header):
    """Prepares the data by separating features and target, and applying scaling."""
    # Separate features (X) and target (y)
    X = [row[:-1] for row in data]  # All columns except the last one (HeartDisease)
    y = [row[-1] for row in data]   # Last column is the target (HeartDisease)
    
    # Add intercept term (column of 1's) to X
    X = [[1] + x for x in X]  # Add a column of 1's for intercept term
    
    # Columns that need scaling
    columns_to_scale = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    scale_indices = [header.index(col) for col in columns_to_scale]  # Get indices of columns to scale
    
    # Columns that are binary/categorical (these will be left unscaled)
    columns_to_leave = ['male', 'education', 'currentSmoker', 'BPMeds', 'prevalentStroke', 
                        'prevalentHyp', 'diabetes']  # Binary and categorical columns
    
    # Extract the columns that need to be scaled (ignores intercept column at index 0)
    X_to_scale = [[row[i] for i in scale_indices] for row in X]

    # Apply StandardScaler to continuous features
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(X_to_scale)

    # Replace the scaled values back into the original X dataset
    for i, row in enumerate(X):
        for j, idx in enumerate(scale_indices):
            row[idx] = scaled_values[i][j]

    return X, y  # Return scaled features X and target y


def split_data(X, y, train_ratio=0.7, val_ratio=0.15):
    """Splits the data into training, validation, and test sets."""
    total = len(X)
    train_end = int(train_ratio * total)
    val_end = train_end + int(val_ratio * total)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test

def sigmoid(z):
    return 1 / (1 + exp(-z))

def dot_product(v1, v2):
    return sum(x * y for x, y in zip(v1, v2))

def clip(predictions, epsilon=1e-10):
    """Clips predictions to avoid log(0) errors."""
    return [max(min(p, 1 - epsilon), epsilon) for p in predictions]
def accuracy(X, y, weights, bias):
    predictions = [1 if sigmoid(dot_product(weights, x) + bias) > 0.5 else 0 for x in X]
    correct = sum(1 for y_i, p in zip(y, predictions) if y_i == p)
    return correct / len(y)

def logistic_regression_fit(X_train, y_train, X_val, y_val, num_steps, learning_rate, batch_size=1):
    # Initialize weights and bias randomly
    weights = [random.uniform(-0.01, 0.01) for _ in range(len(X_train[0]))]
    bias = random.uniform(-0.01, 0.01)

    training_loss = []
    validation_loss = []
    training_accuracy = []
    validation_accuracy = []

    for step in range(num_steps):
        # Shuffle the training data (for stochastic/mini-batch gradient descent)
        indices = list(range(len(X_train)))
        random.shuffle(indices)
        X_train = [X_train[i] for i in indices]
        y_train = [y_train[i] for i in indices]

        for start in range(0, len(X_train), batch_size):
            end = min(start + batch_size, len(X_train))
            batch_X = X_train[start:end]
            batch_y = y_train[start:end]

            # Compute gradients for the current batch
            gradient_w = [0] * len(weights)
            gradient_b = 0

            for i in range(len(batch_X)):
                x = batch_X[i]
                y_i = batch_y[i]
                prediction = sigmoid(dot_product(weights, x) + bias)
                error = y_i - prediction

                # Compute gradient for weights and bias
                for j in range(len(weights)):
                    gradient_w[j] += error * x[j]
                gradient_b += error

            # Average the gradients over the batch
            gradient_w = [g / len(batch_X) for g in gradient_w]
            gradient_b /= len(batch_X)

            # Update weights and bias
            weights = [w + learning_rate * g for w, g in zip(weights, gradient_w)]
            bias += learning_rate * gradient_b

        # Log the training and validation metrics
        if step % 100 == 0 or step == num_steps - 1:
            # Compute training loss and accuracy
            train_loss = -sum([y_i * math.log(sigmoid(dot_product(weights, x) + bias)) +
                               (1 - y_i) * math.log(1 - sigmoid(dot_product(weights, x) + bias))
                               for x, y_i in zip(X_train, y_train)]) / len(X_train)
            train_acc = accuracy(X_train, y_train, weights, bias)

            # Compute validation loss and accuracy
            val_loss = -sum([y_i * math.log(sigmoid(dot_product(weights, x) + bias)) +
                             (1 - y_i) * math.log(1 - sigmoid(dot_product(weights, x) + bias))
                             for x, y_i in zip(X_val, y_val)]) / len(X_val)
            val_acc = accuracy(X_val, y_val, weights, bias)

            training_loss.append(train_loss)
            validation_loss.append(val_loss)
            training_accuracy.append(train_acc)
            validation_accuracy.append(val_acc)

            print(f"Step {step}: Train Loss: {train_loss}, Val Loss: {val_loss}, Train Acc: {train_acc}, Val Acc: {val_acc}")

    return weights, bias, training_loss, validation_loss, training_accuracy, validation_accuracy



def plot_metrics(training_loss, validation_loss, training_accuracy, validation_accuracy):
    iterations = range(0, len(training_loss) * 100, 100)

    plt.figure(figsize=(12, 8))

    # Plot Training and Validation Loss
    plt.subplot(2, 1, 1)
    plt.plot(iterations, training_loss, label="Training Loss")
    plt.plot(iterations, validation_loss, label="Validation Loss")
    plt.xlabel("Iteration")
    plt.ylabel("Loss")
    plt.title("Loss vs. Iteration")
    plt.legend()

    # Plot Training and Validation Accuracy
    plt.subplot(2, 1, 2)
    plt.plot(iterations, training_accuracy, label="Training Accuracy")
    plt.plot(iterations, validation_accuracy, label="Validation Accuracy")
    plt.xlabel("Iteration")
    plt.ylabel("Accuracy")
    plt.title("Accuracy vs. Iteration")
    plt.legend()

    plt.tight_layout()
    plt.show()

def split_data(X, y, train_size=0.7, val_size=0.15):
    """Splits data into training, validation, and test sets."""
    data_size = len(X)
    train_end = int(train_size * data_size)
    val_end = int((train_size + val_size) * data_size)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test
def k_fold_cross_validation(X, y, k=5, num_steps=5000, learning_rate=0.002, batch_size=1):
    # Shuffle data
    combined = list(zip(X, y))
    random.shuffle(combined)
    X, y = zip(*combined)
    
    # Split data into k folds
    fold_size = len(X) // k
    folds_X = [X[i * fold_size:(i + 1) * fold_size] for i in range(k)]
    folds_y = [y[i * fold_size:(i + 1) * fold_size] for i in range(k)]
    
    # Arrays to store the performance metrics for each fold
    accuracies, precisions, recalls, f1_scores = [], [], [], []

    # Perform k-fold cross-validation
    for i in range(k):
        print(f"\nFold {i + 1}/{k}:")
        # Prepare training and validation sets
        X_train = [folds_X[j] for j in range(k) if j != i]
        y_train = [folds_y[j] for j in range(k) if j != i]
        X_val = folds_X[i]
        y_val = folds_y[i]
        
        # Flatten X_train and y_train (since they are currently in a list of lists)
        X_train = [item for sublist in X_train for item in sublist]
        y_train = [item for sublist in y_train for item in sublist]
        
        # Train the logistic regression model on the training folds
        weights, bias, train_loss, val_loss, train_acc, val_acc = logistic_regression_fit(
            X_train, y_train, X_val, y_val, num_steps=num_steps, learning_rate=learning_rate, batch_size=batch_size)
        
        # Evaluate the model on the validation fold
        val_predictions = [1 if sigmoid(dot_product(weights, x) + bias) > 0.5 else 0 for x in X_val]
        accuracy_val = accuracy(X_val, y_val, weights, bias)
        precision_val = precision_score(y_val, val_predictions)
        recall_val = recall_score(y_val, val_predictions)
        f1_val = f1_score(y_val, val_predictions)
        
        # Append metrics
        accuracies.append(accuracy_val)
        precisions.append(precision_val)
        recalls.append(recall_val)
        f1_scores.append(f1_val)

        print(f"Fold {i + 1} - Accuracy: {accuracy_val:.4f}, Precision: {precision_val:.4f}, Recall: {recall_val:.4f}, F1: {f1_val:.4f}")

    # Calculate average and standard deviation of metrics across all folds
    avg_accuracy = sum(accuracies) / k
    avg_precision = sum(precisions) / k
    avg_recall = sum(recalls) / k
    avg_f1 = sum(f1_scores) / k

    std_accuracy = math.sqrt(sum([(x - avg_accuracy) ** 2 for x in accuracies]) / k)
    std_precision = math.sqrt(sum([(x - avg_precision) ** 2 for x in precisions]) / k)
    std_recall = math.sqrt(sum([(x - avg_recall) ** 2 for x in recalls]) / k)
    std_f1 = math.sqrt(sum([(x - avg_f1) ** 2 for x in f1_scores]) / k)

    # Print the final results
    print("\nFinal Cross-Validation Results:")
    print(f"Accuracy: {avg_accuracy:.4f} ± {std_accuracy:.4f}")
    print(f"Precision: {avg_precision:.4f} ± {std_precision:.4f}")
    print(f"Recall: {avg_recall:.4f} ± {std_recall:.4f}")
    print(f"F1 Score: {avg_f1:.4f} ± {std_f1:.4f}")

    return avg_accuracy, avg_precision, avg_recall, avg_f1, std_accuracy, std_precision, std_recall, std_f1

def main():
    # Load and prepare data from 'Heart Disease.csv'
    data, header = load_csv_data('Heart Disease.csv')

    # Prepare the data (splitting into features X and target y, and scaling where needed)
    X, y = prepare_data(data, header)

    # Perform k-fold cross-validation with k=5
    print("Starting k-fold cross-validation...")
    avg_accuracy, avg_precision, avg_recall, avg_f1, std_accuracy, std_precision, std_recall, std_f1 = k_fold_cross_validation(
        X, y, k=5, num_steps=1000, learning_rate=0.002, batch_size=64)

    # Print the final averaged metrics with standard deviation
    print("\nFinal Averaged Metrics from 5-Fold Cross-Validation:")
    print(f"Accuracy: {avg_accuracy:.4f} ± {std_accuracy:.4f}")
    print(f"Precision: {avg_precision:.4f} ± {std_precision:.4f}")
    print(f"Recall: {avg_recall:.4f} ± {std_recall:.4f}")
    print(f"F1 Score: {avg_f1:.4f} ± {std_f1:.4f}")

if __name__ == "__main__":
    main()

from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, roc_auc_score
from math import exp, log
import math
import random
import matplotlib.pyplot as plt
import csv
from sklearn.preprocessing import StandardScaler
import numpy as np


def load_csv_data(filepath):
    """Loads CSV data and handles missing values by replacing 'NA' with the column mean."""
    with open(filepath, 'r') as file:
        csv_reader = csv.reader(file)
        header = next(csv_reader)
        data = [row for row in csv_reader]

    # Transpose data to handle columns
    columns = list(zip(*data))
    
    # Compute means, ignoring 'NA'
    means = []
    for col in columns:
        filtered = [float(x) for x in col if x != 'NA']
        mean = sum(filtered) / len(filtered) if filtered else 0
        means.append(mean)

    # Replace 'NA' with the mean of the column
    new_data = []
    for row in data:
        new_row = [float(row[i]) if row[i] != 'NA' else means[i] for i in range(len(row))]
        new_data.append(new_row)

    return new_data, header  # Return data and header for future reference


def prepare_data(data, header):
    """Prepares the data by separating features and target, and applying scaling."""
    # Separate features (X) and target (y)
    X = [row[:-1] for row in data]  # All columns except the last one (HeartDisease)
    y = [row[-1] for row in data]   # Last column is the target (HeartDisease)
    
    # Add intercept term (column of 1's) to X
    X = [[1] + x for x in X]  # Add a column of 1's for intercept term
    
    # Columns that need scaling
    columns_to_scale = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    scale_indices = [header.index(col) for col in columns_to_scale]  # Get indices of columns to scale
    
    # Columns that are binary/categorical (these will be left unscaled)
    columns_to_leave = ['male', 'education', 'currentSmoker', 'BPMeds', 'prevalentStroke', 
                        'prevalentHyp', 'diabetes']  # Binary and categorical columns
    
    # Extract the columns that need to be scaled (ignores intercept column at index 0)
    X_to_scale = [[row[i] for i in scale_indices] for row in X]

    # Apply StandardScaler to continuous features
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(X_to_scale)

    # Replace the scaled values back into the original X dataset
    for i, row in enumerate(X):
        for j, idx in enumerate(scale_indices):
            row[idx] = scaled_values[i][j]

    return X, y  # Return scaled features X and target y


def split_data(X, y, train_ratio=0.7, val_ratio=0.15):
    """Splits the data into training, validation, and test sets."""
    total = len(X)
    train_end = int(train_ratio * total)
    val_end = train_end + int(val_ratio * total)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test

def sigmoid(z):
    return 1 / (1 + exp(-z))

def dot_product(v1, v2):
    return sum(x * y for x, y in zip(v1, v2))

def clip(predictions, epsilon=1e-10):
    """Clips predictions to avoid log(0) errors."""
    return [max(min(p, 1 - epsilon), epsilon) for p in predictions]
def accuracy(X, y, weights):
    # Assuming bias is already included in the features X (e.g., a column of ones)
    predictions = [1 if sigmoid(dot_product(weights, x)) > 0.5 else 0 for x in X]
    correct = sum(1 for y_i, p in zip(y, predictions) if y_i == p)
    return correct / len(y)

def logistic_regression_fit(X_train, y_train, X_val, y_val, num_steps, learning_rate):
    # Initialize weights and bias randomly
    weights = [random.uniform(-0.01, 0.01) for _ in range(len(X_train[0]))]
    bias = random.uniform(-0.01, 0.01)

    training_loss = []
    validation_loss = []
    training_accuracy = []
    validation_accuracy = []

    for step in range(num_steps):
        # Predict probabilities for the training data
        predictions = [sigmoid(dot_product(weights, x) + bias) for x in X_train]
        clipped_predictions = clip(predictions)  # Clip predictions to avoid log(0)

        # Calculate errors (y - predicted)
        errors = [y_i - p for y_i, p in zip(y_train, clipped_predictions)]

        # Compute gradient
        gradient_weights = [0] * len(weights)
        gradient_bias = 0
        for i in range(len(X_train)):
            for j in range(len(weights)):
                gradient_weights[j] += errors[i] * X_train[i][j]
            gradient_bias += errors[i]
        gradient_weights = [g / len(X_train) for g in gradient_weights]
        gradient_bias /= len(X_train)

        # Update weights and bias using the computed gradient and learning rate
        weights = [w + learning_rate * g for w, g in zip(weights, gradient_weights)]
        bias += learning_rate * gradient_bias

        # Log and track loss and accuracy every 100 steps
        if step % 100 == 0:
            # Calculate training loss
            train_loss = -sum(y_i * math.log(p) + (1 - y_i) * math.log(1 - p) for y_i, p in zip(y_train, clipped_predictions)) / len(X_train)
            training_loss.append(train_loss)

            # Calculate validation loss
            val_predictions = [sigmoid(dot_product(weights, x) + bias) for x in X_val]
            val_loss = -sum(y_i * math.log(p) + (1 - y_i) * math.log(1 - p) for y_i, p in zip(y_val, clip(val_predictions))) / len(X_val)
            validation_loss.append(val_loss)

            # Calculate accuracies
            train_acc = accuracy(X_train, y_train, weights)
            val_acc = accuracy(X_val, y_val, weights)
            training_accuracy.append(train_acc)
            validation_accuracy.append(val_acc)

            print(f'Step {step}: Training Loss: {train_loss}, Validation Loss: {val_loss}, Training Accuracy: {train_acc}, Validation Accuracy: {val_acc}, Bias: {bias}')

    return weights, bias, training_loss, validation_loss, training_accuracy, validation_accuracy



def plot_metrics(training_loss, validation_loss, training_accuracy, validation_accuracy):
    iterations = range(0, len(training_loss) * 100, 100)

    plt.figure(figsize=(12, 8))

    # Plot Training and Validation Loss
    plt.subplot(2, 1, 1)
    plt.plot(iterations, training_loss, label="Training Loss")
    plt.plot(iterations, validation_loss, label="Validation Loss")
    plt.xlabel("Iteration")
    plt.ylabel("Loss")
    plt.title("Loss vs. Iteration")
    plt.legend()

    # Plot Training and Validation Accuracy
    plt.subplot(2, 1, 2)
    plt.plot(iterations, training_accuracy, label="Training Accuracy")
    plt.plot(iterations, validation_accuracy, label="Validation Accuracy")
    plt.xlabel("Iteration")
    plt.ylabel("Accuracy")
    plt.title("Accuracy vs. Iteration")
    plt.legend()

    plt.tight_layout()
    plt.show()

def split_data(X, y, train_size=0.7, val_size=0.15):
    """Splits data into training, validation, and test sets."""
    data_size = len(X)
    train_end = int(train_size * data_size)
    val_end = int((train_size + val_size) * data_size)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test

def compute_logistic_regression_metrics(X_val, y_val, weights, bias=None):
    # Compute the probability predictions from the logistic regression model (sigmoid output)
    if bias is not None:
        predictions_proba = [sigmoid(dot_product(weights, x) + bias) for x in X_val]
    else:
        predictions_proba = [sigmoid(dot_product(weights, x)) for x in X_val]

    # Convert probabilities to binary predictions with a threshold of 0.5
    predictions = [1 if p > 0.3 else 0 for p in predictions_proba]  # Lower threshold to 0.3

    
    # Calculate confusion matrix
    cm = confusion_matrix(y_val, predictions)
    tn, fp, fn, tp = cm.ravel()  # Extract TN, FP, FN, TP from the confusion matrix
    
    # Calculate Precision, Recall, F1 Score, and ROC-AUC
    precision = precision_score(y_val, predictions, zero_division=0)  # Set to 0 to avoid warnings

    recall = recall_score(y_val, predictions)
    f1 = f1_score(y_val, predictions)
    roc_auc = roc_auc_score(y_val, predictions_proba)  # Use probabilities for ROC-AUC

    # Print the confusion matrix and metrics
    print("Confusion Matrix:")
    print(cm)
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1 Score: {f1:.4f}")
    print(f"ROC-AUC Score: {roc_auc:.4f}")

    return cm, precision, recall, f1, roc_auc


def main():
    # Load and prepare data
    data, header = load_csv_data('Heart Disease.csv')

    # Prepare the data (splitting into features X and target y, and scaling where needed)
    X, y = prepare_data(data, header)

    # Split the data into training, validation, and test sets
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(X, y)

    # Train the logistic regression model using batch gradient descent
    weights, bias, train_loss, val_loss, train_acc, val_acc = logistic_regression_fit(
        X_train, y_train, X_val, y_val, num_steps=5000, learning_rate=0.002)

    # Plot the loss and accuracy over iterations
    plot_metrics(train_loss, val_loss, train_acc, val_acc)

    # Compute and print performance metrics for the validation set
    print("\nEvaluation on Validation Set:")
    compute_logistic_regression_metrics(X_val, y_val, weights, bias)

    # Optionally, you can also evaluate on the test set:
    print("\nEvaluation on Test Set:")
    compute_logistic_regression_metrics(X_test, y_test, weights, bias)


if __name__ == "__main__":
    main()

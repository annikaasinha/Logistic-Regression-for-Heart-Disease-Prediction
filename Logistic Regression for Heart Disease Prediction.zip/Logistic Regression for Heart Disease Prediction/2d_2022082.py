import matplotlib.pyplot as plt
import csv
from sklearn.preprocessing import StandardScaler
import random
import math
def logistic_regression_fit(X_train, y_train, X_val, y_val, num_steps, learning_rate, batch_size=1):
    # Initialize weights and bias using Xavier initialization
    weights = [random.uniform(-1, 1) * math.sqrt(2 / len(X_train[0])) for _ in range(len(X_train[0]))]
    bias = random.uniform(-1, 1) * math.sqrt(2 / len(X_train[0]))

    training_loss = []
    validation_loss = []
    training_accuracy = []
    validation_accuracy = []

    for step in range(num_steps):
        # Shuffle the training data (for stochastic/mini-batch gradient descent)
        indices = list(range(len(X_train)))
        random.shuffle(indices)
        X_train = [X_train[i] for i in indices]
        y_train = [y_train[i] for i in indices]

        for start in range(0, len(X_train), batch_size):
            end = min(start + batch_size, len(X_train))
            batch_X = X_train[start:end]
            batch_y = y_train[start:end]

            # Compute gradients for the current batch
            gradient_w = [0] * len(weights)
            gradient_b = 0

            for i in range(len(batch_X)):
                x = batch_X[i]
                y_i = batch_y[i]
                prediction = sigmoid(dot_product(weights, x) + bias)
                error = y_i - prediction

                # Compute gradient for weights and bias
                for j in range(len(weights)):
                    gradient_w[j] += error * x[j]
                gradient_b += error

            # Average the gradients over the batch
            gradient_w = [g / len(batch_X) for g in gradient_w]
            gradient_b /= len(batch_X)

            # Update weights and bias
            weights = [w + learning_rate * g for w, g in zip(weights, gradient_w)]
            bias += learning_rate * gradient_b

        # Log the training and validation metrics
        if step % 100 == 0 or step == num_steps - 1:
            # Compute training loss and accuracy
            train_loss = -sum([y_i * math.log(sigmoid(dot_product(weights, x) + bias)) +
                               (1 - y_i) * math.log(1 - sigmoid(dot_product(weights, x) + bias))
                               for x, y_i in zip(X_train, y_train)]) / len(X_train)
            train_acc = accuracy(X_train, y_train, weights, bias)

            # Compute validation loss and accuracy
            val_loss = -sum([y_i * math.log(sigmoid(dot_product(weights, x) + bias)) +
                             (1 - y_i) * math.log(1 - sigmoid(dot_product(weights, x) + bias))
                             for x, y_i in zip(X_val, y_val)]) / len(X_val)
            val_acc = accuracy(X_val, y_val, weights, bias)

            training_loss.append(train_loss)
            validation_loss.append(val_loss)
            training_accuracy.append(train_acc)
            validation_accuracy.append(val_acc)

            print(f"Step {step}: Train Loss: {train_loss}, Val Loss: {val_loss}, Train Acc: {train_acc}, Val Acc: {val_acc}")

    return weights, bias, training_loss, validation_loss, training_accuracy, validation_accuracy

def sigmoid(z):
    # To avoid math domain error, we clip the value between a small positive value and 1 - small value.
    epsilon = 1e-12  # Small value to avoid log(0)
    return max(min(1 / (1 + math.exp(-z)), 1 - epsilon), epsilon)


def dot_product(weights, features):
    return sum(w * f for w, f in zip(weights, features))

def accuracy(X, y, weights, bias):
    predictions = [1 if sigmoid(dot_product(weights, x) + bias) > 0.5 else 0 for x in X]
    correct = sum(1 for y_i, p in zip(y, predictions) if y_i == p)
    return correct / len(y)

def prepare_data(data, header):
    """Prepares the data by separating features and target, and applying scaling."""
    # Separate features (X) and target (y)
    X = [row[:-1] for row in data]  # All columns except the last one (HeartDisease)
    y = [row[-1] for row in data]   # Last column is the target (HeartDisease)
    
    # Add intercept term (column of 1's) to X
    X = [[1] + x for x in X]  # Add a column of 1's for intercept term
    
    # Columns that need scaling
    columns_to_scale = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    scale_indices = [header.index(col) for col in columns_to_scale]  # Get indices of columns to scale
    
    # Columns that are binary/categorical (these will be left unscaled)
    columns_to_leave = ['male', 'education', 'currentSmoker', 'BPMeds', 'prevalentStroke', 
                        'prevalentHyp', 'diabetes']  # Binary and categorical columns
    
    # Extract the columns that need to be scaled (ignores intercept column at index 0)
    X_to_scale = [[row[i] for i in scale_indices] for row in X]

    # Apply StandardScaler to continuous features
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(X_to_scale)

    # Replace the scaled values back into the original X dataset
    for i, row in enumerate(X):
        for j, idx in enumerate(scale_indices):
            row[idx] = scaled_values[i][j]

    return X, y  # Return scaled features X and target y


def split_data(X, y, train_ratio=0.7, val_ratio=0.15):
    """Splits the data into training, validation, and test sets."""
    total = len(X)
    train_end = int(train_ratio * total)
    val_end = train_end + int(val_ratio * total)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test

def load_csv_data(filepath):
    """Loads CSV data and handles missing values by replacing 'NA' with the column mean."""
    with open(filepath, 'r') as file:
        csv_reader = csv.reader(file)
        header = next(csv_reader)
        data = [row for row in csv_reader]

    # Transpose data to handle columns
    columns = list(zip(*data))
    
    # Compute means, ignoring 'NA'
    means = []
    for col in columns:
        filtered = [float(x) for x in col if x != 'NA']
        mean = sum(filtered) / len(filtered) if filtered else 0
        means.append(mean)

    # Replace 'NA' with the mean of the column
    new_data = []
    for row in data:
        new_row = [float(row[i]) if row[i] != 'NA' else means[i] for i in range(len(row))]
        new_data.append(new_row)

    return new_data, header  # Return data and header for future reference


def main():
    # Load and prepare data
    data, header = load_csv_data('Heart Disease.csv')
    X, y = prepare_data(data, header)

    # Split the data into training, validation, and test sets
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(X, y)

    # Train using Stochastic Gradient Descent (SGD)
    print("Training with Stochastic Gradient Descent (SGD)...")
    weights_sgd, bias_sgd, train_loss_sgd, val_loss_sgd, train_acc_sgd, val_acc_sgd = logistic_regression_fit(
        X_train, y_train, X_val, y_val, num_steps=1000, learning_rate=0.00006, batch_size=1)

    # Train using Mini-Batch Gradient Descent with different batch sizes
    batch_sizes = [16, 64]  # Experiment with different batch sizes
    for batch_size in batch_sizes:
        print(f"\nTraining with Mini-Batch Gradient Descent (Batch Size = {batch_size})...")
        weights_mbgd, bias_mbgd, train_loss_mbgd, val_loss_mbgd, train_acc_mbgd, val_acc_mbgd = logistic_regression_fit(
            X_train, y_train, X_val, y_val, num_steps=1000, learning_rate=0.00009, batch_size=batch_size)

        # Plot loss and accuracy for each batch size
        plot_metrics_comparison(train_loss_sgd, val_loss_sgd, train_acc_sgd, val_acc_sgd,
                                train_loss_mbgd, val_loss_mbgd, train_acc_mbgd, val_acc_mbgd, batch_size)


def plot_metrics_comparison(train_loss_sgd, val_loss_sgd, train_acc_sgd, val_acc_sgd,
                            train_loss_mbgd, val_loss_mbgd, train_acc_mbgd, val_acc_mbgd, batch_size):
    # Plot loss vs iteration
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.plot(train_loss_sgd, label='SGD - Train Loss')
    plt.plot(val_loss_sgd, label='SGD - Val Loss')
    plt.plot(train_loss_mbgd, label=f'Mini-Batch (Batch Size={batch_size}) - Train Loss')
    plt.plot(val_loss_mbgd, label=f'Mini-Batch (Batch Size={batch_size}) - Val Loss')
    plt.title('Loss vs Iteration')
    plt.xlabel('Iteration')
    plt.ylabel('Loss')
    plt.legend()

    # Plot accuracy vs iteration
    plt.subplot(1, 2, 2)
    plt.plot(train_acc_sgd, label='SGD - Train Acc')
    plt.plot(val_acc_sgd, label='SGD - Val Acc')
    plt.plot(train_acc_mbgd, label=f'Mini-Batch (Batch Size={batch_size}) - Train Acc')
    plt.plot(val_acc_mbgd, label=f'Mini-Batch (Batch Size={batch_size}) - Val Acc')
    plt.title('Accuracy vs Iteration')
    plt.xlabel('Iteration')
    plt.ylabel('Accuracy')
    plt.legend()

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()

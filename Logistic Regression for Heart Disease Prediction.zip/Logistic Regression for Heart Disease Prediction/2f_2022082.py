import matplotlib.pyplot as plt
import random
import math
import csv
from sklearn.preprocessing import StandardScaler
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score
def split_data(X, y, train_ratio=0.7, val_ratio=0.15):
    """Splits the data into training, validation, and test sets."""
    total = len(X)
    train_end = int(train_ratio * total)
    val_end = train_end + int(val_ratio * total)

    X_train = X[:train_end]
    y_train = y[:train_end]
    X_val = X[train_end:val_end]
    y_val = y[train_end:val_end]
    X_test = X[val_end:]
    y_test = y[val_end:]

    return X_train, X_val, X_test, y_train, y_val, y_test

def prepare_data(data, header):
    """Prepares the data by separating features and target, and applying scaling."""
    # Separate features (X) and target (y)
    X = [row[:-1] for row in data]  # All columns except the last one (HeartDisease)
    y = [row[-1] for row in data]   # Last column is the target (HeartDisease)
    
    # Add intercept term (column of 1's) to X
    X = [[1] + x for x in X]  # Add a column of 1's for intercept term
    
    # Columns that need scaling
    columns_to_scale = ['age', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose']
    scale_indices = [header.index(col) for col in columns_to_scale]  # Get indices of columns to scale
    
    # Columns that are binary/categorical (these will be left unscaled)
    columns_to_leave = ['male', 'education', 'currentSmoker', 'BPMeds', 'prevalentStroke', 
                        'prevalentHyp', 'diabetes']  # Binary and categorical columns
    
    # Extract the columns that need to be scaled (ignores intercept column at index 0)
    X_to_scale = [[row[i] for i in scale_indices] for row in X]

    # Apply StandardScaler to continuous features
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(X_to_scale)

    # Replace the scaled values back into the original X dataset
    for i, row in enumerate(X):
        for j, idx in enumerate(scale_indices):
            row[idx] = scaled_values[i][j]

    return X, y  # Return scaled features X and target y

def load_csv_data(filepath):
    """Loads CSV data and handles missing values by replacing 'NA' with the column mean."""
    with open(filepath, 'r') as file:
        csv_reader = csv.reader(file)
        header = next(csv_reader)
        data = [row for row in csv_reader]

    # Transpose data to handle columns
    columns = list(zip(*data))
    
    # Compute means, ignoring 'NA'
    means = []
    for col in columns:
        filtered = [float(x) for x in col if x != 'NA']
        mean = sum(filtered) / len(filtered) if filtered else 0
        means.append(mean)

    # Replace 'NA' with the mean of the column
    new_data = []
    for row in data:
        new_row = [float(row[i]) if row[i] != 'NA' else means[i] for i in range(len(row))]
        new_data.append(new_row)

    return new_data, header  # Return data and header for future reference


def sigmoid(z):
    epsilon = 1e-12  # Small value to avoid log(0)
    return max(min(1 / (1 + math.exp(-z)), 1 - epsilon), epsilon)

def dot_product(weights, features):
    return sum(w * f for w, f in zip(weights, features))

def accuracy(X, y, weights, bias):
    predictions = [1 if sigmoid(dot_product(weights, x) + bias) > 0.5 else 0 for x in X]
    correct = sum(1 for y_i, p in zip(y, predictions) if y_i == p)
    return correct / len(y)

def logistic_regression_with_regularization_and_early_stopping(X_train, y_train, X_val, y_val, num_steps, learning_rate, batch_size, l1_reg, l2_reg, patience):
    weights = [random.uniform(-1, 1) * math.sqrt(2 / len(X_train[0])) for _ in range(len(X_train[0]))]
    bias = random.uniform(-1, 1) * math.sqrt(2 / len(X_train[0]))
    best_loss = float('inf')
    steps_since_improvement = 0

    training_loss = []
    validation_loss = []
    training_accuracy = []
    validation_accuracy = []

    for step in range(num_steps):
        indices = list(range(len(X_train)))
        random.shuffle(indices)
        X_train = [X_train[i] for i in indices]
        y_train = [y_train[i] for i in indices]

        for start in range(0, len(X_train), batch_size):
            end = min(start + batch_size, len(X_train))
            batch_X = X_train[start:end]
            batch_y = y_train[start:end]

            gradient_w = [0] * len(weights)
            gradient_b = 0

            for i in range(len(batch_X)):
                x = batch_X[i]
                y_i = batch_y[i]
                prediction = sigmoid(dot_product(weights, x) + bias)
                error = y_i - prediction

                for j in range(len(weights)):
                    gradient_w[j] += error * x[j] - l1_reg * sign(weights[j]) - 2 * l2_reg * weights[j]
                gradient_b += error

            gradient_w = [g / len(batch_X) for g in gradient_w]
            gradient_b /= len(batch_X)

            weights = [w + learning_rate * g for w, g in zip(weights, gradient_w)]
            bias += learning_rate * gradient_b

        if step % 100 == 0 or step == num_steps - 1:
            train_loss = compute_loss(X_train, y_train, weights, bias, l1_reg, l2_reg)
            train_acc = accuracy(X_train, y_train, weights, bias)
            val_loss = compute_loss(X_val, y_val, weights, bias, l1_reg, l2_reg)
            val_acc = accuracy(X_val, y_val, weights, bias)

            training_loss.append(train_loss)
            validation_loss.append(val_loss)
            training_accuracy.append(train_acc)
            validation_accuracy.append(val_acc)

            if val_loss < best_loss:
                best_loss = val_loss
                steps_since_improvement = 0
            else:
                steps_since_improvement += 1

            if steps_since_improvement >= patience:
                print(f"Early stopping triggered after {step} iterations.")
                break

            print(f"Step {step}: Train Loss: {train_loss}, Val Loss: {val_loss}, Train Acc: {train_acc}, Val Acc: {val_acc}")

    return weights, bias, training_loss, validation_loss, training_accuracy, validation_accuracy

def sign(x):
    if x > 0:
        return 1
    elif x < 0:
        return -1
    else:
        return 0

def compute_loss(X, y, weights, bias, l1_reg, l2_reg):
    loss = -sum(y_i * math.log(sigmoid(dot_product(weights, x) + bias)) + (1 - y_i) * math.log(1 - sigmoid(dot_product(weights, x) + bias)) for x, y_i in zip(X, y)) / len(X)
    l1_penalty = l1_reg * sum(abs(w) for w in weights)
    l2_penalty = l2_reg * sum(w**2 for w in weights)
    return loss + l1_penalty + l2_penalty


def main():
    # Load and prepare data (assuming CSV file loading and data preparation functions are defined)
    data, header = load_csv_data('Heart Disease.csv')
    X, y = prepare_data(data, header)

    # Split the data into training, validation, and test sets
    X_train, X_val, X_test, y_train, y_val, y_test = split_data(X, y)

    # Parameters
    num_steps = 10000
    batch_size = 64
    learning_rates = [0.001, 0.0001]  # Example learning rates
    l1_reg = 0.01
    l2_reg = 0.01
    patience = 200  # Number of steps to continue without improvement in validation loss

    results = []

    # Run experiments with different learning rates
    for lr in learning_rates:
        print(f"\nTraining with learning rate: {lr}")
        weights, bias, train_loss, val_loss, train_acc, val_acc = logistic_regression_with_regularization_and_early_stopping(
            X_train, y_train, X_val, y_val, num_steps, lr, batch_size, l1_reg, l2_reg, patience)
        
        results.append((train_loss, val_loss, train_acc, val_acc, f"LR: {lr}"))

    # Plotting the results
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    for i, (train_loss, val_loss, train_acc, val_acc, label) in enumerate(results):
        # Plot Loss
        axes[0, 0].plot(train_loss, label=f'Train Loss - {label}')
        axes[0, 1].plot(val_loss, label=f'Val Loss - {label}')

        # Plot Accuracy
        axes[1, 0].plot(train_acc, label=f'Train Acc - {label}')
        axes[1, 1].plot(val_acc, label=f'Val Acc - {label}')

    for ax in axes.ravel():
        ax.set_xlabel('Iteration')
        ax.legend()

    axes[0, 0].set_title('Training Loss')
    axes[0, 1].set_title('Validation Loss')
    axes[1, 0].set_title('Training Accuracy')
    axes[1, 1].set_title('Validation Accuracy')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
